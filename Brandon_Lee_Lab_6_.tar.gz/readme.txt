Question 1. The reason why my selectionsort is a stable sort is because when i compare each values, i dont use '=' operator.
    So, even if values have the same value, they will not activate the swap function.
    
Question 2. inputs 1,1,0,3,3,3,2  this code is testing on my main.cc
