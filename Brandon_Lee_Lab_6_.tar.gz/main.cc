// Name: Brandon Lee
// SID: 861054437
// May 18, 2015
// Spring 2015 Section 23
// TA: Dingwem Tao

#include "selectionsort.h"
#include <iostream>
#include <vector>
#include <list>
#include <utility>
#include <set>
#include <array>

using namespace std;

int main(){
    
    list<int> u;
    u.push_back(2);
    u.push_back(4);
    u.push_back(5);
    u.push_back(1);
    u.push_back(8);
    u.push_back(9);
    
    cout << "Pre: " << u << endl;
    selectionsort(u);
    cout << "Post: " << u << endl << endl;
    count = 0;
    
    vector< pair< int,int > > v;
    v.push_back(pair< int,int >(1,2));
    v.push_back(pair< int,int >(3,-1));
    v.push_back(pair< int,int >(-1,3));
    v.push_back(pair< int,int >(0,0));
    v.push_back(pair< int,int >(2,3));
    v.push_back(pair< int,int >(1,2));
    v.push_back(pair< int,int >(1,-2));
    v.push_back(pair< int,int >(8,10));
    
    cout << "Pre: " << v <<endl;
    selectionsort(v);
    cout << "Post: "<< v <<endl;
    cout << count << " moves" << endl << endl;
    count = 0;
    
    list< pair<int, int> > x;
    x.push_back( pair< int, int >(10,2));
    x.push_back( pair< int, int >(-3,-1));
    x.push_back( pair< int, int >(-8,0));
    x.push_back( pair< int, int >(1,1));
    x.push_back( pair< int, int >(1,1));
    x.push_back( pair< int, int >(0,0));
    x.push_back( pair< int, int >(10,2));
    x.push_back( pair< int, int >(5,5));
    x.push_back( pair< int, int >(5,-5));
    x.push_back( pair< int, int >(0,0));
    x.push_back( pair< int, int >(10,2));
    
    cout << "Pre: " << x << endl;
    selectionsort(x);
    cout << "Post: " << x << endl;
    cout << count << " moves" << endl << endl;
    count = 0;
    
    cout << "For question 2." << endl;
    list< int > y;
    y.push_back(1);
    y.push_back(1);
    y.push_back(0);
    y.push_back(3);
    y.push_back(3);
    y.push_back(3);
    y.push_back(2);
    
    cout << "Pre: " << y << endl;
    selectionsort(y);
    cout << "Post: " << y << endl;
    cout << "There will be two swaps and six moves (one swap = 3 moves)." << endl;
    cout << count << " moves" << endl << endl;
    count = 0;
    
    return 0;
}