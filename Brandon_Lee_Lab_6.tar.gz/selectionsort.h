#ifndef SORT_H
#define SORT_H
#include <iostream>
#include <list>
#include <vector>
using namespace std;

ostream& operator<<(ostream& os, const vector<int> &v){
    for(unsigned i = 0; i < v.size(); ++i){
        os<< v[i] << " ";
    }
    return os;
}

ostream& operator<<( ostream& os, const vector<pair< int,int > > &v) {
    for( unsigned i = 0; i < v.size(); ++i) {
        os << "(" << v[i].first << "," << v[i].second << ") ";
    }
    return os;
}


ostream& operator<<(ostream& os, const list< int > &v){
    for(auto it = v.begin(); it != v.end(); ++it){
        os<< *it << " ";
    }
    return os;
}

ostream& operator<<( ostream& os, const list< pair<int,int> > &v) {
    for( auto it = v.begin(); it != v.end(); ++it) {
        os << "(" << it->first << "," << it->second << ") ";
    }
    return os;
}

template<typename L>
typename L::iterator min(L &l,  typename L::iterator i){
    auto min = i;
    for (auto j= i; j != l.end(); j++){
        if( *(j) < *(min)){
            min = j;
        }
    }
    return min;
}

//i made counting the amount of swaps a global variable
int count = 0;

template<typename L>
void selectionsort(L &l){
    for(auto i=l.begin(); i != (l.end()); i++){
        auto start = i;
        auto m = min(l, i);
        if(*m < *start){
            swap(*i, *m);
            count += 3;
        }
    }
}

// template<typename L, typename M>
// void selectionsort( L &l ) {
//     for( auto i = l.begin(); i != (l.end() - 1); ++i ) {
//         // auto start = i;
//         // auto m = min( l, i+1 )
//     }
// }

#endif